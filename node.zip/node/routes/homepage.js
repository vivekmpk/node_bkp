var express = require('express'),router = express.Router();
var { homepage } = require('../controller/homepageControl');
router.get('/', homepage);
module.exports = router;


