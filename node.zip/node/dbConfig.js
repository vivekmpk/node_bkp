var dbConfig = {

    database : {
        host : 'localhost',
        user : 'root',
        password : '',
        dbName : 'sample',
        port : '3306'
    },
    server:{
        host: 'http://localhost',
        port: '5000'
    }
}

module.exports = dbConfig; 