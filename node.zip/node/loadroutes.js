var loadroutes = 
{
 homepage : require('./routes/homepage'),
}
module.exports = loadroutes; 