let common_hlp = require('../helper/common_helper');
let _ = require('lodash');
var homepage = {
    homepage : async (req,res) =>{
        //Get Banner Details 
        /*let bannerCondition = {
            'table' : 'bannerdata',
            'dbWhere' : { 'status' : 0, 'isDeleted' : 0, 'type' : 'homebanner' },
            'returnData' : 'title,images'
        }
        let data = await common_hlp.getMasterList(req,res,bannerCondition);*/
        let data = { 'sample':'data'};
    
        res.render('homepage', {
            title           : 'Home Page'+req.app.locals.webtitle,
            messages        : '',
            sampleData      : data,
            pageName : 'homepage'

        });
    }


}

module.exports = homepage;